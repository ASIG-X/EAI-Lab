clear;close all;

data_folder = 'data/seq1_txt/';

imu_data = readmatrix(fullfile(data_folder,'imu_data.txt'),'NumHeaderLines',1);
t_imu = imu_data(:,1) + 1e-9*imu_data(:,2);
acc   = imu_data(:,3:5)*9.81;   % ax ay az
gyro  = imu_data(:,6:8)*pi/180;   % gx gy gz

uwb_data = readmatrix(fullfile(data_folder,'uwb_data.txt'),'NumHeaderLines',1);
t_uwb = uwb_data(:,1) + 1e-9*uwb_data(:,2);
uwb = uwb_data(:,3:8);

pos_an = zeros(3,6);
pos_an(:,1) = [0;0;0];
pos_an(:,2) = [2.7;0;0];
pos_an(:,3) = [2.7;4.8;0];
pos_an(:,4) = [0;4.8;0];
pos_an(:,5) = [0;2.4;2];
pos_an(:,6) = [2.7;2.4;2];

n_uwb = size(uwb,1);
pos_est = zeros(3,n_uwb);
for i = 1:n_uwb
  toa_meas = uwb(i,:);
  z = toa_meas(1)^2 - toa_meas(2:end)'.^2 - sum(pos_an(:,1).^2,1) + sum(pos_an(:,2:end).^2,1)';
  H = 2*(pos_an(:,2:end)-pos_an(:,1))';
  hat_x = (H'*H)^(-1)*H'*z;
  pos_est(:,i) = hat_x;
end

fig = figure;
plot3(pos_est(1,:),pos_est(2,:),pos_est(3,:),'-k','LineWidth',1.5); hold on;
scatter3(pos_an(1,:),pos_an(2,:),pos_an(3,:),300,'g','filled','LineWidth',2); hold on;
axis equal;
grid on;
xlabel('x [m]');
ylabel('y [m]');
zlabel('z [m]');