clear;close all;

data_folder = 'data/seq1_txt/';

imu_data = readmatrix(fullfile(data_folder,'imu_data.txt'),'NumHeaderLines',1);
t_imu = imu_data(:,1) + 1e-9*imu_data(:,2);
acc   = imu_data(:,3:5)*9.81;   % ax ay az
gyro  = imu_data(:,6:8)*pi/180;   % gx gy gz

uwb_data = readmatrix(fullfile(data_folder,'uwb_data.txt'),'NumHeaderLines',1);
t_uwb = uwb_data(:,1) + 1e-9*uwb_data(:,2);
uwb = uwb_data(:,3:8);

t0 = min([t_uwb(1),t_imu(1)]);
figure
for i = 1:6
  plot(t_uwb - t0,uwb(:,i),'LineWidth',2);hold on;
end
xlabel('time [s]');
ylabel('TOA [m]');
legend('0','1','2','3','4','5');
grid on;

figure
for i = 1:3
  plot(t_imu - t0,acc(:,i),'LineWidth',2);hold on;
end
xlabel('time [s]');
ylabel('acc [m/s^2]');
legend('x','y','z');
grid on;

figure
for i = 1:3
  plot(t_imu - t0,gyro(:,i),'LineWidth',2);hold on;
end
xlabel('time [s]');
ylabel('gyro [rad/s]');
legend('x','y','z');
grid on;