#!/usr/bin/env python3

import sys
import rosbag2_py
from rosidl_runtime_py.utilities import get_message
from rclpy.serialization import deserialize_message


def extract_custom_imu(
    bag_path,
    imu_topic="/imu",
    output_file="imu_data.txt"
):
    reader = rosbag2_py.SequentialReader()
    storage_options = rosbag2_py.StorageOptions(
        uri=bag_path,
        storage_id="sqlite3"
    )
    converter_options = rosbag2_py.ConverterOptions(
        input_serialization_format="cdr",
        output_serialization_format="cdr"
    )
    reader.open(storage_options, converter_options)

    # Find topic type
    topic_types = reader.get_all_topics_and_types()
    imu_type = None
    for topic in topic_types:
        if topic.name == imu_topic:
            imu_type = topic.type
            break

    if imu_type is None:
        raise RuntimeError(f"IMU topic '{imu_topic}' not found in bag")

    msg_type = get_message(imu_type)

    with open(output_file, "w") as f:
        # Header
        f.write(
            "sec nsec "
            "acc_x acc_y acc_z "
            "gyro_x gyro_y gyro_z\n"
        )

        while reader.has_next():
            topic, data, timestamp = reader.read_next()

            if topic != imu_topic:
                continue

            msg = deserialize_message(data, msg_type)

            # Expecting: values = [acc.x, acc.y, acc.z, gyro.x, gyro.y, gyro.z]
            values = msg.values

            if len(values) != 6:
                raise RuntimeError(
                    f"Expected 6 values, got {len(values)}"
                )

            f.write(
                f"{msg.header.stamp.sec} "
                f"{msg.header.stamp.nanosec} "
                f"{values[0]} {values[1]} {values[2]} "
                f"{values[3]} {values[4]} {values[5]}\n"
            )

    print(f"IMU data saved to: {output_file}")

def extract_uwb(
    bag_path,
    uwb_topic="/uwb",
    output_file="uwb_data.txt"
):
    # Open ros2 bag
    reader = rosbag2_py.SequentialReader()
    storage_options = rosbag2_py.StorageOptions(
        uri=bag_path,
        storage_id="sqlite3"
    )
    converter_options = rosbag2_py.ConverterOptions(
        input_serialization_format="cdr",
        output_serialization_format="cdr"
    )
    reader.open(storage_options, converter_options)

    # Find UWB topic type
    topic_types = reader.get_all_topics_and_types()
    uwb_type = None
    for topic in topic_types:
        if topic.name == uwb_topic:
            uwb_type = topic.type
            break

    if uwb_type is None:
        raise RuntimeError(f"UWB topic '{uwb_topic}' not found in bag")

    msg_type = get_message(uwb_type)

    with open(output_file, "w") as f:
        # Write header
        f.write(
            "sec nsec "
            "toa0 toa1 toa2 toa3 toa4 toa5\n"
        )

        while reader.has_next():
            topic, data, timestamp = reader.read_next()

            if topic != uwb_topic:
                continue

            msg = deserialize_message(data, msg_type)

            # values = [toa0, toa1, toa2, toa3, toa4, toa5]
            values = msg.values

            if len(values) != 6:
                raise RuntimeError(
                    f"Expected 6 TOA values, got {len(values)}"
                )

            f.write(
                f"{msg.header.stamp.sec} "
                f"{msg.header.stamp.nanosec} "
                f"{values[0]} {values[1]} {values[2]} "
                f"{values[3]} {values[4]} {values[5]}\n"
            )

    print(f"UWB data saved to: {output_file}")

if __name__ == "__main__":
    if len(sys.argv) < 4:
        print("Usage: python3 ./convertROSbag2Txt.py <bag_path> [imu_topic] [uwb_topic] <out_path>. e.g., python3 ./convertROSbag2Txt.py recorded_bag1 /cf2/imu_data /cf2/uwb_data recorded_data_txt")
        sys.exit(1)

    bag_path = sys.argv[1]
    imu_topic = sys.argv[2] if len(sys.argv) > 2 else "/imu"
    uwb_topic = sys.argv[3] if len(sys.argv) > 3 else "/uwb"
    out_path = sys.argv[4] if len(sys.argv) > 3 else "./"

    extract_custom_imu(bag_path, imu_topic, out_path + "/imu_data.txt")
    extract_uwb(bag_path, uwb_topic, out_path + "/uwb_data.txt")
