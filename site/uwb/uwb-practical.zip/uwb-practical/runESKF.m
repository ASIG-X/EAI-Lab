clear;close all;

data_folder = 'data/seq1_txt/';

imu_data = readmatrix(fullfile(data_folder,'imu_data.txt'),'NumHeaderLines',1);
t_imu = imu_data(:,1) + 1e-9*imu_data(:,2);
acc   = imu_data(:,3:5)*9.81;   % ax ay az
gyro  = imu_data(:,6:8)*pi/180;   % gx gy gz

uwb_data = readmatrix(fullfile(data_folder,'uwb_data.txt'),'NumHeaderLines',1);
t_uwb = uwb_data(:,1) + 1e-9*uwb_data(:,2);
uwb = uwb_data(:,3:8);

pos_an = zeros(3,6);
pos_an(:,1) = [0;0;0];
pos_an(:,2) = [2.7;0;0];
pos_an(:,3) = [2.7;4.8;0];
pos_an(:,4) = [0;4.8;0];
pos_an(:,5) = [0;2.4;2];
pos_an(:,6) = [2.7;2.4;2];


n_uwb = size(uwb,1);

cov_acc = eye(3);
cov_gyro = 0.1*eye(3);
s_tag_b = [0.02,0,0.015]'; % Coordinates of UWB tag w.r.t. the IMU frame
var_toa = 1;

% intialize state
t0 = t_imu(1);                  
t_imu = t_imu - t0;
t_uwb = t_uwb - t0;
x0 = zeros(10,1); % [position, linear velocity, orientation (qw;qx;qy;qz)]
x0(1:3) = [-3;2;1.5]; % Should be set roughly to the initial position
x0(7) = 1;
P0 = eye(9);

[t_mix,imu_id,toa_id] = mixTwoMeas(t_imu',t_uwb');
t_max = numel(t_mix);
all_x = zeros(10,t_max);
xi = x0;
Pi = P0;
dxi = zeros(9,1);
t_last = 0;
acc_last = [0;0;9.81];
grv = [0;0;9.81];
Qa_last = cov_acc;   
gyro_last = zeros(3,1);
Qg_last = cov_gyro;  
for i_t = 1:t_max
  t_sens = t_mix(i_t);
  [xi,Pi] = predict(t_sens-t_last,xi,Pi,grv,acc_last,gyro_last,Qa_last,Qg_last);
  if imu_id(i_t)
    id = imu_id(i_t);
    acc_last = acc(id,:)';
    Qa_last = cov_acc;
    gyro_last = gyro(id,:)';
    Qg_last = cov_gyro;
  end
  t_last = t_sens;

  if toa_id(i_t)
    idx = toa_id(i_t);
    toa_meas = uwb(idx,:);
    [xi,dxi,Pi] = update(xi,dxi,Pi,toa_meas,s_tag_b,pos_an,var_toa);
    [dxi,Pi] = reset(dxi,Pi);
  end  
  all_x(:,i_t) = xi;
end

fig = figure;
plot3(all_x(1,:),all_x(2,:),all_x(3,:),'-k','LineWidth',1.5); hold on;
scatter3(pos_an(1,:),pos_an(2,:),pos_an(3,:),300,'g','filled','LineWidth',2); hold on;
axis equal;
grid on;
xlabel('x [m]');
ylabel('y [m]');
zlabel('z [m]');

function [t_mix,t1_id,t2_id] = mixTwoMeas(t1,t2)
  [t_mix, t1_id] = sort([t1,t2]);
  t2_id = t1_id - numel(t1);
  t1_id(t2_id>0) = 0;
  t2_id(t2_id<=0) = 0;
end

function [x,P] = predict(T,x,P,grv,acc_last,gyro_last,Qa,Qg)
  Q = blkdiag(Qa,Qg);

  s = x(1:3);
  v = x(4:6);
  r = x(7:10);
  R = q2R(r);
  
  wacc = R*acc_last - grv;

  x(1:3) = s + v*T + 0.5*wacc*T^2;
  x(4:6) = v + wacc*T; 
  x(7:10) = qprod(r,qexp(0.5*gyro_last*T));
  
  Ft = eye(9);
  Ft(1:3,4:6) = T*eye(3);
  Ft(4:6,7:9) = -2*T*R*skewsm(acc_last);
  Ft(7:9,7:9) = expm(-T*skewsm(gyro_last));

  Bt = zeros(9,6);
  Bt(4:6,1:3) = -T*R;
  Bt(7:9,4:6) = -0.5*T*eye(3);
  
  P = Ft*P*Ft' + Bt*Q*Bt';
end

function [x,dx,P] = update(x,dx,P,toa,t_tag,pos_ani,var_tdoa)
  s = x(1:3);
  r = x(7:10);
  R = q2R(r);

  s_tag = R*t_tag + s;
  n_toa = size(toa,2);
  rng_l = sqrt(sum((s_tag-pos_ani).^2,1));
  toa_pred = rng_l;
  innv = (toa - toa_pred)';
  
  Js = 1./rng_l'.*(s_tag-pos_ani)';
  Jr = Js*drot(r,t_tag);
  Jx = [Js,zeros(n_toa,3),Jr];
  Q_dtheta = Qleft(r)*[zeros(1,3);eye(3)];
  Jtx = blkdiag(eye(6),Q_dtheta);
  H = Jx*Jtx;
  
  M = H*P*H' + var_tdoa*eye(n_toa);
  
  K = P*(H')*inv(M);
  P = (eye(9) - K*H)*P;
  derror = dx + K*innv;
  
  x(1:6) = x(1:6) + derror(1:6);
  x(7:10) = qprod(r,qexp(derror(7:9)));
  
  dx = derror;
end   

function [dx,P] = reset(dx,P)
  Gdth = eye(3) - skewsm(dx(7:9));
  G = blkdiag(eye(6),Gdth);
  P = G*P*G';
  dx = zeros(9,1);
end

function R = q2R(q)
  tmp = q*q';
  
  R11 = tmp(1) + tmp(6) - tmp(11) - tmp(16);
  R12 = 2*(tmp(7) - tmp(4));
  R13 = 2*(tmp(3) + tmp(8));
  R21 = 2*(tmp(4) + tmp(7));
  R22 = tmp(1) - tmp(6) + tmp(11) - tmp(16);
  R23 = 2*(tmp(12) - tmp(2));
  R31 = 2*(tmp(8) - tmp(3));
  R32 = 2*(tmp(12) + tmp(2));
  R33 = tmp(1) - tmp(6) - tmp(11) + tmp(16);
  R = [R11,R12,R13;
       R21,R22,R23;
       R31,R32,R33];
end   

function q = qexp(delta)
  delta_norm = sqrt(sum(delta.^2));
  q = [cos(delta_norm);sinc(delta_norm/pi).*delta];
end    

function qout = qprod(q1, q2)
  vec = [q1(1,:).*q2(2,:); q1(1,:).*q2(3,:); q1(1,:).*q2(4,:)] + ...
    [q2(1,:).*q1(2,:); q2(1,:).*q1(3,:); q2(1,:).*q1(4,:)] + ...
    [q1(3,:).*q2(4,:)-q1(4,:).*q2(3,:);
    q1(4,:).*q2(2,:)-q1(2,:).*q2(4,:); 
    q1(2,:).*q2(3,:)-q1(3,:).*q2(2,:)];

  scalar = q1(1,:).*q2(1,:) - q1(2,:).*q2(2,:) - q1(3,:).*q2(3,:) - q1(4,:).*q2(4,:);
  qout = [scalar;vec];
end

function pL = Qleft(q)
  pL = [q(1),-q(2),-q(3),-q(4);
        q(2),q(1),-q(4),q(3);
        q(3),q(4),q(1),-q(2);
        q(4),-q(3),q(2),q(1)];
end 

function m = skewsm(v)
  m = [0,-v(3),v(2);
       v(3),0,-v(1);
       -v(2),v(1),0];
end 

function J = drot(q,v)
  rw = q(1);
  rv = q(2:end);
  dvp_dw = 2*(rw*v + cross(rv,v));
  dvp_dv = 2*(sum(rv.*v)*eye(3) - skewsm(cross(rv,v)) - rw*skewsm(v));
  J = [dvp_dw,dvp_dv];
end
